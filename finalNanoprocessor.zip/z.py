import os

directory = "NanoProcessor.srcs"
output_file = "nano-anu.txt"
extensions = ('.vhd','.xdc')

with open(output_file, 'w', encoding='utf-8') as out:
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(extensions):
                file_path = os.path.join(root, file)
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    out.write(f"\n----- {file_path} -----\n")
                    out.write(f.read())
                    out.write("\n" + "-"*50 + "\n")